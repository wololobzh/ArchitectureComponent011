package fr.wololo.tpairquality.ui.utils

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import fr.wololo.tpairquality.repository.AppDatabase
import fr.wololo.tpairquality.ui.home.HomeViewModel
import java.lang.Exception

class ViewModelFactory(val context: Context) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T
    {
        if(modelClass.isAssignableFrom(HomeViewModel::class.java))
        {
            val dao = AppDatabase.getInstance(context).getLieuDao()
            return HomeViewModel(dao) as T
        }

        throw Exception("Ce ViewModel n'existe pas")
    }


}