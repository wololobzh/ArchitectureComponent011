package fr.wololo.tpairquality.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import fr.wololo.tpairquality.entities.Lieu
import fr.wololo.tpairquality.repository.LieuDao

class HomeViewModel(val dao:LieuDao) : ViewModel() {

    var lieu:Lieu = Lieu()

    fun ajouter()
    {
        dao.insert(lieu)
    }
}