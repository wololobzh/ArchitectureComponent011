package fr.wololo.tpairquality.ui.gallery

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import fr.wololo.tpairquality.databinding.FragmentGalleryBinding
import fr.wololo.tpairquality.repository.AppDatabase

class GalleryFragment : Fragment() {

    private var _binding: FragmentGalleryBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val galleryViewModel = ViewModelProvider(this).get(GalleryViewModel::class.java)
        val db = FragmentGalleryBinding.inflate(inflater, container, false)

        var liste = AppDatabase.getInstance(context as Context).getLieuDao().get()
        for(item in liste)
        {
            Log.i("ACOS",item.toString())
        }

        return db.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}