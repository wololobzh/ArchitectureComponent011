package fr.wololo.tpairquality

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import fr.wololo.tpairquality.entities.Lieu
import fr.wololo.tpairquality.entities.Personne
import fr.wololo.tpairquality.repository.AppDatabase
import fr.wololo.tpairquality.repository.LieuDao
import fr.wololo.tpairquality.repository.PersonneDao
import org.junit.After

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*
import org.junit.Before

/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4::class)
class LieuDaoTest {

    private lateinit var lieuDao: LieuDao
    private lateinit var db: AppDatabase

    lateinit var p1 : Lieu
    lateinit var p2 : Lieu
    lateinit var p3 : Lieu
    lateinit var p4 : Lieu
    lateinit var p5 : Lieu

    @Before
    @Throws(Exception::class)
    fun creerBdd()
    {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        lieuDao = db.getLieuDao()

        p1 = Lieu(0,"Caen",5f)
        p2 = Lieu(0,"Soliers",5f)
        p3 = Lieu(0,"Limoges",0f)
        p4 = Lieu(0,"Rennes",0f)
        p5 = Lieu(0,"Cherbourg",0f)

        lieuDao.insert(p1)
        lieuDao.insert(p2)
        lieuDao.insert(p3)
        lieuDao.insert(p4)
        lieuDao.insert(p5)
    }

    @Test
    fun get() {
        var liste = lieuDao.get()
        assertTrue(liste[0].nom == p1.nom)
        assertTrue(liste[0].note == p1.note)
        assertTrue(liste[1].nom == p2.nom)
        assertTrue(liste[1].note == p2.note)
        assertTrue(liste[2].nom == p3.nom)
        assertTrue(liste[2].note == p3.note)
        assertTrue(liste[3].nom == p4.nom)
        assertTrue(liste[3].note == p4.note)
        assertTrue(liste[4].nom == p5.nom)
        assertTrue(liste[4].note == p5.note)
    }

    @Test
    fun insert()
    {
        var p6 = Lieu(0,"Lille",5f)

        lieuDao.insert(p6)

        var lieuRecupere = lieuDao.get().get(5)

        assertTrue(lieuRecupere.nom == p6.nom)
        assertTrue(lieuRecupere.note == p6.note)
    }
}