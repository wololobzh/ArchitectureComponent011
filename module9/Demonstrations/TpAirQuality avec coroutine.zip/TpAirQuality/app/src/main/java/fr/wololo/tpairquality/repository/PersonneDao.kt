package fr.wololo.tpairquality.repository

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import fr.wololo.tpairquality.entities.Personne

@Dao
interface PersonneDao
{
    @Query("SELECT * FROM Personne")
    fun get():List<Personne>

    @Query("SELECT * FROM Personne WHERE Id = :id")
    fun get(id:Int):Personne

    @Insert
    fun insert(vararg personne : Personne):Unit
}