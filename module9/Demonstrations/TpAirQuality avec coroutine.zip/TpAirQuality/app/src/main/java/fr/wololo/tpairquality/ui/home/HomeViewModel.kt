package fr.wololo.tpairquality.ui.home

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import fr.wololo.tpairquality.entities.Lieu
import fr.wololo.tpairquality.repository.LieuDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class HomeViewModel(val dao:LieuDao) : ViewModel() {

    var lieu:Lieu = Lieu()

    fun ajouter()
    {
        viewModelScope.launch {
            dao.insert(lieu)
        }
    }
}