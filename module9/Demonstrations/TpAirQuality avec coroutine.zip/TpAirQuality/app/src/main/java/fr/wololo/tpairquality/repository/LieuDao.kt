package fr.wololo.tpairquality.repository

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import fr.wololo.tpairquality.entities.Lieu

@Dao
interface LieuDao
{
    @Query("SELECT * FROM Lieu")
    fun get():LiveData<List<Lieu>>

    @Insert
    suspend fun insert(lieu:Lieu)
}