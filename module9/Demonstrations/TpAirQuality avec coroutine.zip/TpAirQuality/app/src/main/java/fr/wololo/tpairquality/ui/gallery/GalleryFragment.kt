package fr.wololo.tpairquality.ui.gallery

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import fr.wololo.tpairquality.databinding.FragmentGalleryBinding
import fr.wololo.tpairquality.repository.AppDatabase

class GalleryFragment : Fragment() {

    private var _binding: FragmentGalleryBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val galleryViewModel = ViewModelProvider(this).get(GalleryViewModel::class.java)
        val db = FragmentGalleryBinding.inflate(inflater, container, false)

        var observerDeListe = AppDatabase.getInstance(context as Context).getLieuDao().get()

        observerDeListe.observe(viewLifecycleOwner, Observer {
            for (item in it)
            {
                Log.i("ACOS","${item}")
            }
        })


        return db.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}