package fr.wololo.tpairquality.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Personne(@PrimaryKey(autoGenerate = true) var id:Int=0, var nom:String="", var prenom:String="")
