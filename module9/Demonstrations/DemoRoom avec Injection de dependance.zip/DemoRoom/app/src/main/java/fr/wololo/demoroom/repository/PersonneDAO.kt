package fr.wololo.demoroom.repository

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import fr.wololo.demoroom.entity.Personne

@Dao
interface PersonneDAO
{
    @Query("SELECT * FROM Personne")
    fun get():List<Personne>

    @Query("SELECT * FROM Personne WHERE Id = :id")
    fun get(id:Int):Personne

    @Insert
    fun insert(vararg personne : Personne):Unit
}