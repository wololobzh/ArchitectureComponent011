package fr.wololo.demoroom.utils

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import fr.wololo.demoroom.MainActivityViewModel
import fr.wololo.demoroom.repository.AppDatabase
import java.lang.Exception

class ViewModelFactory(private val context: Context) : ViewModelProvider.Factory
{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {

        if(modelClass.isAssignableFrom(MainActivityViewModel::class.java) )
        {
            var dao = AppDatabase.getInstance(context).getPersonneDao()
            var vm = MainActivityViewModel(dao);
            return vm as T;
        }

        throw Exception("VM inexistant")
    }
}