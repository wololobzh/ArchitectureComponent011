package fr.wololo.demoroom

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import fr.wololo.demoroom.entity.Personne
import fr.wololo.demoroom.repository.AppDatabase
import fr.wololo.demoroom.repository.PersonneDAO

class MainActivityViewModel(val dao:PersonneDAO) : ViewModel()
{
    var personne = MutableLiveData<Personne>()

    init {
        if(dao.get().size == 0) {
            var p1 = Personne(prenom = "John",nom="Rambo")
            var p2 = Personne(nom="Kira",id=0,prenom = "Sha")
            var p3 = Personne(prenom = "Miou",nom="Miou")
            var p4 = Personne(prenom = "Bip",nom="Bip")
            var p5 = Personne(prenom = "Co",nom="Yotte")
            dao.insert(p1,p2,p3,p4,p5)
        }

        personne.value = dao.get(1)
        Log.i("ACOS","dao.get(1) " + personne.value )

    }

    fun random()
    {
        var fin = dao.get().size

        Log.i("ACOS","Info : " + fin)

        var idRandom = (1..fin).random()

        Log.i("ACOS","idRandom : " + idRandom)

        personne.value = dao.get(idRandom);

        Log.i("ACOS","personne.value : " + personne.value)



    }
}