package fr.wololo.demoroom.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Personne(@PrimaryKey(autoGenerate = true) var id:Int, var nom:String, var prenom:String)
