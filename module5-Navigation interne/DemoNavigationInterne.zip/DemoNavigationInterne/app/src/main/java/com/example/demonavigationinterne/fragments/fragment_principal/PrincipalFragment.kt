package com.example.demonavigationinterne.fragments.fragment_principal

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.demonavigationinterne.R
import com.example.demonavigationinterne.databinding.FragmentPrincipalBinding


class PrincipalFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        var vb = FragmentPrincipalBinding.inflate(layoutInflater)

        vb.btnMaison.setOnClickListener {
            Navigation.createNavigateOnClickListener(R.id.action_principalFragment_to_maisonFragment).onClick(it)
        }

        vb.btnTravail.setOnClickListener {
            Navigation.createNavigateOnClickListener(R.id.action_principalFragment_to_travailFragment).onClick(it)
        }

        vb.btnVoyage.setOnClickListener {
            Navigation.createNavigateOnClickListener(R.id.action_principalFragment_to_voyageFragment).onClick(it)
        }

        return vb.root
    }


}