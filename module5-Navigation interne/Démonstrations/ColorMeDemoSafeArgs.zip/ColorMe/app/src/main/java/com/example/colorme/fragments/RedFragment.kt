package com.example.colorme.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.colorme.R
import com.example.colorme.databinding.FragmentBlankBinding
import com.example.colorme.databinding.FragmentRedBinding


class RedFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var vb = FragmentRedBinding.inflate(layoutInflater)


        vb.btnValider.setOnClickListener {
            if ((vb.etNom.text.toString().hashCode() + vb.etMot.text.toString().hashCode()) > 0) {
                Navigation.createNavigateOnClickListener(R.id.action_redFragment_to_orangeFragment)
                    .onClick(it)
            }else{
                Navigation.createNavigateOnClickListener(R.id.action_redFragment_to_blueFragment)
                    .onClick(it)
            }
        }

        return vb.root
    }
}