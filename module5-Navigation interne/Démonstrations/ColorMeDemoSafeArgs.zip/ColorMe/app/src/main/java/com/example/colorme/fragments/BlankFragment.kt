package com.example.colorme.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.colorme.R
import com.example.colorme.databinding.FragmentBlankBinding


class BlankFragment : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       var vb = FragmentBlankBinding.inflate(layoutInflater)

       //définit le corps de l'unique méthode de l'interface de la classe anonyme attendue par un onClick
       vb.btnValider.setOnClickListener {

           if(vb.etPrenom.text.toString().hashCode() / 1_000_000 > 665)
           {
               //it represente le bouton
               Navigation.createNavigateOnClickListener(R.id.action_blankFragment_to_redFragment).onClick(it)
           }else{
               Navigation.createNavigateOnClickListener(R.id.action_blankFragment_to_pinkFragment).onClick(it)
           }
       }

       return vb.root
    }


}