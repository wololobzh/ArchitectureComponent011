package com.example.colorme.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.colorme.R
import com.example.colorme.databinding.FragmentBlankBinding
import com.example.colorme.databinding.FragmentPinkBinding


class PinkFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var vb = FragmentPinkBinding.inflate(layoutInflater)

        vb.btnValider.setOnClickListener {

            if(vb.etNom.text.toString().hashCode() - vb.etAnnee.text.toString().toInt() > 0)
            {
                Navigation.createNavigateOnClickListener(R.id.action_pinkFragment_to_yellowFragment).onClick(it)
            }else{
                Navigation.createNavigateOnClickListener(R.id.action_pinkFragment_to_greenFragment).onClick(it)
            }

        }


        return vb.root
    }
}