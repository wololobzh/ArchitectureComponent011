package com.example.bestfinger

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.example.bestfinger.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {


    //onCreate est un callBack lié au cycle de vie de l'activité
    override fun onCreate(savedInstanceState: Bundle?)
    {
        //On appelle la classe mère qui fait des trucs
        super.onCreate(savedInstanceState)

        //Récupération d'un objet représentant mon ihm et aucune données n'est encore dans la vue
        var db = ActivityMainBinding.inflate(layoutInflater)



        //Récupération de l'état de l'ihm et de sa logique
        var vm = ViewModelProvider(this).get(FingerVM::class.java)

        //J'injecte le VM dans l'ihm pour que l'ihm ait ses données à afficher
        db.model = vm

        //Lien entre la logique du vm et les interactions utilisateurs
        db.btnDroite.setOnClickListener {
            vm.clickBoutonDroit()
            //Pour mettre à jour l'ihm
            db.model = vm
        }

        //Lien entre la logique du vm et les interactions utilisateurs
        db.btnGauche.setOnClickListener {
            vm.clickBoutonGauche()
            //Pour mettre à jour l'ihm
            db.model = vm
        }

        //La fonction setContentView créée la vue à l'écran
        setContentView(db.root)
    }
}