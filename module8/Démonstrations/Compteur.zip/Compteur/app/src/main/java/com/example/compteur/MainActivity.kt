package com.example.compteur

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.compteur.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    var compteur = 0;
    lateinit var tv:TextView
    lateinit var vm:CompteurViewModel
    lateinit var db:ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //db est un objet qui contient ^plusieurs objets contenant chacun un des elements graphique de la vue
        db = ActivityMainBinding.inflate(layoutInflater)
        //vm est le model de la vue qui contient l'état et la logique de la vue
        vm = ViewModelProvider(this).get(CompteurViewModel::class.java)
        //construction de la vue

        vm.compteur.observe(this, Observer { db.vm = vm })

        setContentView(db.root)
    }
}