package com.example.bestfinger

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class FingerVM : ViewModel()
{
    var nombreTotalLanceDeDes = 0
    var nombreTotalLanceDeDesAGauche = 0
    var nombreTotalLanceDeDesADroite = 0
    var sommeGauche = 0
    var sommeDroite = 0
    var image = MutableLiveData<Int>()

    init {
        image.value = R.drawable.un
    }

    fun clickBoutonDroit()
    {
        nombreTotalLanceDeDesADroite++
        sommeDroite += lancesDeDes()
    }

    fun clickBoutonGauche()
    {
        nombreTotalLanceDeDesAGauche++
        sommeGauche += lancesDeDes()
    }

    fun lancesDeDes() : Int
    {
        var valeurDes = (1..6).random()
        when(valeurDes) {
            1->image.value=R.drawable.un
            2->image.value=R.drawable.deux
            3->image.value=R.drawable.trois
            4->image.value=R.drawable.quatre
            5->image.value=R.drawable.cinq
            6->image.value=R.drawable.six
        }
        nombreTotalLanceDeDes++
        return valeurDes
    }
}