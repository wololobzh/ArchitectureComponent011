package com.example.bestfinger

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.bestfinger.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    //onCreate est un callBack lié au cycle de vie de l'activité
    override fun onCreate(savedInstanceState: Bundle?)
    {
        //On appelle la classe mère qui fait des trucs
        super.onCreate(savedInstanceState)
        //Récupération d'un objet représentant mon ihm et aucune données n'est encore dans la vue
        var db = ActivityMainBinding.inflate(layoutInflater)
        //Récupération de l'état de l'ihm et de sa logique
        var vm = ViewModelProvider(this).get(FingerVM::class.java)

        vm.image.observe(this, Observer {
            db.model = vm  //J'injecte le VM dans l'ihm pour que l'ihm ait ses données à afficher
        })
        //La fonction setContentView créée la vue à l'écran
        setContentView(db.root)
    }
}