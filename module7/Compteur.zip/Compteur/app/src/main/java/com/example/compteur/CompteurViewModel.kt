package com.example.compteur

import androidx.lifecycle.ViewModel

class CompteurViewModel : ViewModel() {

    var compteur = 0

    fun plusUn()
    {
        compteur++
    }

}