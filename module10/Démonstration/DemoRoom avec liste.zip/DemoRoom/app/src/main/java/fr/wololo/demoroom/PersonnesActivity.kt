package fr.wololo.demoroom

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import fr.wololo.demoroom.adapter.PersonnesAdapter
import fr.wololo.demoroom.databinding.ActivityPersonnesBinding
import fr.wololo.demoroom.repository.AppDatabase

class PersonnesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vb = ActivityPersonnesBinding.inflate(layoutInflater)

        val adapter = PersonnesAdapter()

        vb.rvPersonnes.adapter = adapter

        var lobserve = AppDatabase.getInstance(this).getPersonneDao().get()

        lobserve.observe(this, Observer {
            adapter.submitList(it)
        })


        setContentView(vb.root)
    }
}