package fr.wololo.demoroom.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import fr.wololo.demoroom.databinding.LigneRvPersonnesBinding
import fr.wololo.demoroom.entity.Personne

class PersonnesAdapter : ListAdapter<Personne, PersonnesAdapter.MonViewHolder>(PersonneDiffCallback())
{
    //Demande de creation dun conteneur : Methode appelée par le système
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MonViewHolder
    {
        return MonViewHolder.from(parent)
    }

    //Demande de modification du conteneur : Methode appelée par le système
    override fun onBindViewHolder(holder: MonViewHolder, position: Int) {
        var personne = getItem(position)
        holder.bind(personne)
    }

    class MonViewHolder(var item:LigneRvPersonnesBinding) : RecyclerView.ViewHolder(item.root)
    {
        //Modification du contenu d'un conteneur
        fun bind(personne:Personne)
        {
            item.lePrenom = personne.prenom
        }

        //Creation d'un conteneur
        companion object {
            fun from(parent: ViewGroup) : MonViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                var binding = LigneRvPersonnesBinding.inflate(layoutInflater,parent,false)
                return MonViewHolder(binding)
            }
        }
    }
}

//Ici c'est toujurs pareil aussi
class PersonneDiffCallback : DiffUtil.ItemCallback<Personne>()
{
    override fun areItemsTheSame(oldItem: Personne, newItem: Personne): Boolean
    {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Personne, newItem: Personne): Boolean
    {
        return oldItem == newItem
    }
}