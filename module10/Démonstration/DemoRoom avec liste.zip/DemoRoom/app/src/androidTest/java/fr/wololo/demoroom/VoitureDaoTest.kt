package fr.wololo.demoroom

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import fr.wololo.demoroom.entity.Personne
import fr.wololo.demoroom.repository.AppDatabase
import fr.wololo.demoroom.repository.PersonneDAO
import org.junit.After

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*
import org.junit.Before

/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4::class)
class VoitureDaoTest {

    private lateinit var personneDao: PersonneDAO
    private lateinit var db: AppDatabase

    @Before
    @Throws(Exception::class)
    fun creerBdd()
    {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        personneDao = db.getPersonneDao()
    }

    @Test
    fun test1() {
        var p1 = Personne(0,"Cosson","Gui")//1
        var p2 = Personne(0,"Roussel","Sandy")//2
        var p3 = Personne(0,"Kilo","Anthony")//3
        var p4 = Personne(0,"Tare","Romain")//4

        personneDao.insert(p1)
        personneDao.insert(p2)
        personneDao.insert(p3)
        personneDao.insert(p4)

        var personnerRecuperee = personneDao.get(4)


        assertEquals(p4.nom,personnerRecuperee.nom)
        assertEquals(p4.prenom,personnerRecuperee.prenom)
    }
}