package fr.wololo.tpairquality.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import fr.wololo.tpairquality.databinding.ItemLieuBinding
import fr.wololo.tpairquality.entities.Lieu
import fr.wololo.tpairquality.entities.Personne

class LieuxAdapter(val clickListener: LieuListener) : androidx.recyclerview.widget.ListAdapter<Lieu, LieuxAdapter.MonViewHolder>(LieuDiffCallback())
{
    //Demande de creation dun conteneur : Methode appelée par le système
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MonViewHolder
    {
        return MonViewHolder.from(parent)
    }

    //Demande de modification du conteneur : Methode appelée par le système
    override fun onBindViewHolder(holder: MonViewHolder, position: Int) {
        var lieu = getItem(position)
        holder.bind(lieu, clickListener)
    }

    class MonViewHolder(var item:ItemLieuBinding) : RecyclerView.ViewHolder(item.root)
    {
        //Modification du contenu d'un conteneur
        fun bind(unLieu:Lieu, clickListener: LieuListener)
        {
            item.model = unLieu
            item.clickListener = clickListener
        }

        //Creation d'un conteneur
        companion object {
            fun from(parent: ViewGroup) : MonViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                var binding = ItemLieuBinding.inflate(layoutInflater,parent,false)
                return MonViewHolder(binding)
            }
        }
    }
}

//Ici c'est toujurs pareil aussi
class LieuDiffCallback : DiffUtil.ItemCallback<Lieu>()
{
    override fun areItemsTheSame(oldItem: Lieu, newItem: Lieu): Boolean
    {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Lieu, newItem: Lieu): Boolean
    {
        return oldItem == newItem
    }
}

class LieuListener(val clickListener: (lieuId: Long) -> Unit)
{
    fun onClick(lieu: Lieu) = clickListener(lieu.id)
}