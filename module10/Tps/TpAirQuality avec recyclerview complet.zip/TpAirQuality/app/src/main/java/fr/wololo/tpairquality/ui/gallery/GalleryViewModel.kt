package fr.wololo.tpairquality.ui.gallery

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import fr.wololo.tpairquality.repository.LieuDao

class GalleryViewModel(val dao:LieuDao) : ViewModel() {

    val lieux = dao.get()
}