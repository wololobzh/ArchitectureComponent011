package fr.wololo.tpairquality.ui.gallery

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import fr.wololo.tpairquality.databinding.FragmentGalleryBinding
import fr.wololo.tpairquality.repository.AppDatabase
import fr.wololo.tpairquality.ui.adapter.LieuListener
import fr.wololo.tpairquality.ui.adapter.LieuxAdapter
import fr.wololo.tpairquality.ui.utils.ViewModelFactory

class GalleryFragment : Fragment() {

    private var _binding: FragmentGalleryBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val galleryViewModel = ViewModelProvider(this,ViewModelFactory(context as Context)).get(GalleryViewModel::class.java)
        val db = FragmentGalleryBinding.inflate(inflater, container, false)

        var adapter = LieuxAdapter(LieuListener { lieuId ->
            Toast.makeText(context, "coucou : ${lieuId}", Toast.LENGTH_LONG).show()
        })

        db.rvLieux.adapter = adapter

        galleryViewModel.lieux.observe(viewLifecycleOwner, Observer {
            adapter.submitList(it);
        })

        return db.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}