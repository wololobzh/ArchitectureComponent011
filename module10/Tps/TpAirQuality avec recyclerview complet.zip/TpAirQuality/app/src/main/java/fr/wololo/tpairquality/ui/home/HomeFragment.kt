package fr.wololo.tpairquality.ui.home

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import fr.wololo.tpairquality.databinding.FragmentHomeBinding
import fr.wololo.tpairquality.ui.utils.ViewModelFactory

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val homeViewModel = ViewModelProvider(this,ViewModelFactory(context as Context)).get(HomeViewModel::class.java)
        val db = FragmentHomeBinding.inflate(inflater, container, false)

        db.model = homeViewModel

        return db.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
    }
}