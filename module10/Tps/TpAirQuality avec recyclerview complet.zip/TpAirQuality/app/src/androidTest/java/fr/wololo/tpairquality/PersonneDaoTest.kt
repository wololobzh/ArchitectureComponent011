package fr.wololo.tpairquality

import android.util.Log
import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import fr.wololo.tpairquality.entities.Personne
import fr.wololo.tpairquality.repository.AppDatabase
import fr.wololo.tpairquality.repository.PersonneDao
import org.junit.After

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*
import org.junit.Before

/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4::class)
class PersonneDaoTest {

    private lateinit var personneDao: PersonneDao
    private lateinit var db: AppDatabase

    lateinit var p1: Personne
    lateinit var p2:Personne
    lateinit var p3:Personne
    lateinit var p4:Personne

    @Before
    @Throws(Exception::class)
    fun creerBdd()
    {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        personneDao = db.getPersonneDao()

        p1 = Personne(0,"Cosson","Gui")//1
        p2 = Personne(0,"Roussel","Sandy")//2
        p3 = Personne(0,"Kilo","Anthony")//3
        p4 = Personne(0,"Tare","Romain")//4

        personneDao.insert(p1)
        personneDao.insert(p2)
        personneDao.insert(p3)
        personneDao.insert(p4)
    }

    @Test
    fun insert() {
        var personnerRecuperee = personneDao.get(4)
        assertEquals(p4.nom,personnerRecuperee.nom)
        assertEquals(p4.prenom,personnerRecuperee.prenom)
    }

    @Test
    fun get() {
        var liste =  personneDao.get()
        assertTrue(liste.size > 0)
    }

    @Test
    fun getById()
    {
        var personneRecupere = personneDao.get(1)

        assertEquals(p1.nom,personneRecupere.nom)
        assertEquals(p1.prenom,personneRecupere.prenom)
    }
}